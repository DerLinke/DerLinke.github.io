# 🚀 mydash - Interaktives Terminal Dashboard

[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](LICENSE)
[![Python 3.x](https://img.shields.io/badge/python-3.x-blue.svg)](https://www.python.org)

**mydash** ist dein persönliches Kontrollzentrum für das Terminal. Es bietet eine echte, grafische Benutzeroberfläche (TUI) direkt in deinem Terminal, in der du deine am häufigsten genutzten Befehle organisieren und mit der Tastatur oder der Maus ausführen kannst.

---

## ✨ Features

- 🖥️ **Echte Grafische TUI:** Vollflächige Darstellung mit modernem Layout (basierend auf Textual).
- 🖱️ **Maus-Support:** Volle Unterstützung für Mausklicks und Scrolling.
- 🎨 **Cyberpunk Design:** Auffälliger Glitch-Banner und Neon-Akzente.
- 📂 **Kategorien:** Organisiere deine Befehle übersichtlich in Gruppen (z.B. System, Projekte, Netzwerk).
- ⚙️ **CLI-Verwaltung:** Füge Befehle direkt über das normale Terminal hinzu oder entferne sie.
- 🏠 **Auto-Start:** Kann automatisch als "Startseite" beim Öffnen des Terminals genutzt werden.

---

## 🛠 Installation

### Der schnellste Weg (APT Repository)
Da `mydash` Teil des zentralen **DerLinke Repositories** ist, kannst du es einfach so installieren:

1. Repository hinzufügen (falls noch nicht geschehen):
   ```bash
   curl -s https://derlinke.github.io/derlinke-repo.gpg.key | gpg --dearmor | sudo tee /usr/share/keyrings/derlinke-repo.gpg > /dev/null
   echo "deb [signed-by=/usr/share/keyrings/derlinke-repo.gpg] https://derlinke.github.io/ stable main" | sudo tee /etc/apt/sources.list.d/derlinke.list
   ```

2. Installieren:
   ```bash
   sudo apt update
   sudo apt install mydash
   ```

### Installation via pipx (isolierte Umgebung)
`mydash` wird sauber in einer isolierten Umgebung über `pipx` installiert.

1. Stelle sicher, dass `pipx` installiert ist:
   ```bash
   sudo apt update
   sudo apt install pipx
   pipx ensurepath
   ```

2. Klone das Repository und starte den Installer:
   ```bash
   git clone https://github.com/DerLinke/mydash.git
   cd mydash
   chmod +x install.sh
   ./install.sh
   ```

### Automatische Startseite (Optional)
Damit `mydash` bei jedem Öffnen eines neuen Terminals erscheint, füge folgenden Code ganz am Ende deiner `~/.bashrc` ein:

```bash
# Start mydash Dashboard (Interactive only)
if [[ $- == *i* ]]; then
    mydash
fi
```

---

## 🚀 Nutzung

### Dashboard starten
Starte die grafische Oberfläche mit:
```bash
mydash
```
*Tipp: Beende das Dashboard jederzeit mit der Taste `q`.*

### Befehle verwalten (über CLI)
Du kannst Befehle verwalten, ohne das grafische Menü öffnen zu müssen:

**Befehl hinzufügen:**
```bash
mydash --add "Update System" --cmd "sudo apt update && sudo apt upgrade" --category "System"
```

**Befehl entfernen:**
```bash
mydash --remove "Update System"
```

---

## 📂 Konfiguration

Die Struktur deiner Befehle wird in einer einfachen JSON-Datei gespeichert, die du auch manuell bearbeiten kannst:
`~/.config/mydash/config.json`

Beispiel-Struktur:
```json
{
    "System": [
        {
            "name": "System Update",
            "cmd": "sudo apt update && sudo apt upgrade"
        }
    ]
}
```

---
<p align="center">
  <img src="https://derlinke.github.io/logo.svg" width="300" alt="Logo"><br>
  <strong>DerLinke Software Zentrale</strong><br>
  <a href="https://derlinke.github.io/">Offizielle Webseite</a> | <a href="https://github.com/DerLinke/mydash">GitHub Repository</a>
</p>
